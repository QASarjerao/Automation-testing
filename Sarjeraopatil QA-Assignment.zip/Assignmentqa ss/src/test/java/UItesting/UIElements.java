package UItesting;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class UIElements {

	public static void main(String[] args) throws Exception {
		 System.setProperty("WebDriver,gecko.driver", "C:\\\\sarjueclipse/geckodriver");
		  WebDriver d=new FirefoxDriver();
		  String username = "demo-user";
		  String password = "Demo@321!";
		  String url = "demo.maanch.com";
		  String authUrl = "https://" + username + ":" + password + "@" + url;
		  d.get(authUrl);
		  d.manage().window().maximize();
		  d.findElement(By.xpath("//a[contains(text(),'Make an impact')]")).click();
		  Thread.sleep(1000);
		  d.findElement(By.xpath("//a[contains(text(),'Show more')]")).click();
		  
		  
		  //login form
		  d.findElement(By.id("email")).sendKeys("nex@gmail.com");
		  d.findElement(By.id("password")).sendKeys("12345678");
		  d.findElement(By.xpath("//button[contains(text(),'Login')]")).click();
		  Thread.sleep(1000);
		  JavascriptExecutor Scrolld=(JavascriptExecutor)d;
		  Scrolld.executeScript("window.scrollBy(0,1000)");
		  
		  //saerch textbox 
		  d.findElement(By.id("search_text")).sendKeys("sick");
		  Thread.sleep(1000);
		  d.findElement(By.linkText("The People's Dispensary For Sick Animals")).click();
		  Thread.sleep(2000);
		  d.findElement(By.xpath("//body/nav[1]/div[1]/div[1]/a[1]/img[1]")).click();
		  d.findElement(By.xpath(" //a[@id='dropdownMenuLink']")).click();
		  d.findElement(By.linkText("Logout")).click();
		  d.close();
		 
		  


        
 
		  



		  




		  
		

	}

}
