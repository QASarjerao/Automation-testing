package Functionalitytesting;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Registrationform {

	public static void main(String[] args) throws Exception {
		 System.setProperty("WebDriver,gecko.driver", "C:\\\\sarjueclipse/geckodriver");
		  WebDriver d=new FirefoxDriver();
		  String username = "demo-user";
		  String password = "Demo@321!";
		  String url = "demo.maanch.com";
		  String authUrl = "https://" + username + ":" + password + "@" + url;
		  d.get(authUrl);
		  d.manage().window().maximize();
		  d.findElement(By.xpath("//a[contains(text(),'Login/Sign up')]")).click();
		  Thread.sleep(1000);
		  
		//Registration form with Invalid data
		  //d.findElement(By.id("name")).sendKeys("1234");
		  //d.findElement(By.id("reg-email")).sendKeys("nex");
		  //d.findElement(By.id("reg-password")).sendKeys("******");
		  //d.findElement(By.id("password-confirm")).sendKeys("******");
		  //d.findElement(By.xpath("//button[contains(text(),'Register')]")).click();
		  
		  
			//Registration form with valid data
		  d.findElement(By.id("name")).sendKeys("1234");
		  d.findElement(By.id("reg-email")).sendKeys("nex12@gmail.com");
		  d.findElement(By.id("reg-password")).sendKeys("******");
		  d.findElement(By.id("password-confirm")).sendKeys("******");
		  d.findElement(By.xpath("//button[contains(text(),'Register')]")).click();
		  d.close();


		

	}

}
